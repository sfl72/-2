import os
import sys
import subprocess
from pathlib import Path

class ProjectChecker:
    def __init__(self):
        self.project_root = Path(__file__).parent
        self.required_files = [
            'app/app.py',
            'templates/index.html',
            'run.py',
            'setup.py',
            'run_tests.py',
            'requirements.txt',
            'README.md',
            '.gitignore'
        ]
        self.required_dirs = [
            'app',
            'templates',
            'tests'
        ]
    
    def check_structure(self):
        """检查项目结构完整性"""
        print("检查项目结构...")
        all_ok = True
        
        # 检查必需的目录
        for dir_name in self.required_dirs:
            dir_path = self.project_root / dir_name
            if dir_path.exists() and dir_path.is_dir():
                print(f"✅ {dir_name}/")
            else:
                print(f"❌ {dir_name}/ 不存在")
                all_ok = False
        
        # 检查必需的文件
        for file_name in self.required_files:
            file_path = self.project_root / file_name
            if file_path.exists() and file_path.is_file():
                print(f"✅ {file_name}")
            else:
                print(f"❌ {file_name} 不存在")
                all_ok = False
        
        return all_ok
    
    def check_git(self):
        """检查Git仓库状态"""
        print("\n检查Git仓库...")
        try:
            result = subprocess.run(['git', 'rev-parse', '--is-inside-work-tree'], 
                                  cwd=self.project_root, 
                                  capture_output=True, text=True)
            if result.stdout.strip() == 'true':
                print("✅ Git仓库已初始化")
                
                # 检查最近的提交
                result = subprocess.run(['git', 'log', '--oneline', '-n', '3'], 
                                      cwd=self.project_root, 
                                      capture_output=True, text=True)
                print("最近的提交:")
                print(result.stdout)
                return True
            else:
                print("❌ Git仓库未正确初始化")
                return False
        except Exception as e:
            print(f"❌ Git检查失败: {e}")
            return False
    
    def check_dependencies(self):
        """检查依赖安装状态"""
        print("\n检查依赖...")
        try:
            import flask
            print(f"✅ Flask已安装 (版本: {flask.__version__})")
            return True
        except ImportError:
            print("❌ Flask未安装")
            return False
    
    def run(self):
        """运行完整的项目检查"""
        print("="*60)
        print("倒计时器应用 - 项目状态检查")
        print("="*60)
        
        structure_ok = self.check_structure()
        git_ok = self.check_git()
        deps_ok = self.check_dependencies()
        
        print("\n" + "="*60)
        if structure_ok and git_ok and deps_ok:
            print("✅ 项目状态正常 - 所有检查通过!")
            return True
        else:
            print("❌ 项目状态异常 - 存在问题需要解决")
            return False

if __name__ == '__main__':
    checker = ProjectChecker()
    success = checker.run()
    sys.exit(0 if success else 1)