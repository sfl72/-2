import os
import sys
import subprocess
import venv

class EnvironmentBuilder:
    def __init__(self):
        self.project_dir = os.path.dirname(os.path.abspath(__file__))
        self.venv_dir = os.path.join(self.project_dir, 'venv')
    
    def create_virtual_env(self):
        """创建Python虚拟环境"""
        print("正在创建虚拟环境...")
        venv.create(self.venv_dir, with_pip=True)
        print(f"虚拟环境已创建: {self.venv_dir}")
    
    def install_dependencies(self):
        """安装项目依赖"""
        print("正在安装依赖...")
        
        # 确定pip路径
        if os.name == 'nt':  # Windows
            pip_path = os.path.join(self.venv_dir, 'Scripts', 'pip')
        else:  # Unix/Linux/Mac
            pip_path = os.path.join(self.venv_dir, 'bin', 'pip')
        
        try:
            subprocess.check_call([
                pip_path, 'install', '-r', 
                os.path.join(self.project_dir, 'requirements.txt')
            ])
            print("依赖安装完成")
        except subprocess.CalledProcessError as e:
            print(f"安装失败: {e}")
            sys.exit(1)
    
    def show_instructions(self):
        """显示使用说明"""
        print("\n" + "="*50)
        print("倒计时器应用 - 环境设置完成")
        print("="*50)
        print("\n项目已准备就绪！使用方法：")
        
        if os.name == 'nt':  # Windows
            print("1. 激活虚拟环境:")
            print("   venv\\Scripts\\activate")
            print("2. 启动应用:")
            print("   python run.py")
        else:  # Unix/Linux/Mac
            print("1. 激活虚拟环境:")
            print("   source venv/bin/activate")
            print("2. 启动应用:")
            print("   python run.py")
        
        print("\n访问 http://localhost:5000 查看应用")
        print("按 Ctrl+C 停止服务器")
    
    def run(self):
        """执行完整的环境设置流程"""
        self.create_virtual_env()
        self.install_dependencies()
        self.show_instructions()

if __name__ == '__main__':
    builder = EnvironmentBuilder()
    builder.run()