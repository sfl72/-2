# 倒计时器应用 

## 项目概述

这是一个基于Python Flask的倒计时器Web应用，具有以下功能：

- 创建多个倒计时任务
- 为每个任务设置标题
- 开始、暂停和继续倒计时
- 显示暂停时长
- 简洁美观的用户界面
- 支持深色/浅色模式切换

## 开发者信息

- 开发者: 31
- 邮箱: 3049614571@qq.com

## 技术栈

- Python 3.7+
- Flask Web框架
- HTML/CSS/JavaScript
- Bootstrap 5

## 安装与运行

1. 克隆仓库：
   ```bash
   git clone <repository-url>
   cd countdown-timer
   ```

2. 创建虚拟环境并安装依赖：
   ```bash
   python -m venv venv
   source venv/bin/activate  # Linux/Mac
   # 或
   venv\\Scripts\\activate   # Windows
   
   pip install -r requirements.txt
   ```

3. 运行应用：
   ```bash
   python run.py
   ```

4. 在浏览器中访问 `http://localhost:5000`

## 功能特性

### 倒计时功能
- 可以为每个倒计时设置自定义时长
- 显示剩余时间（MM:SS格式）
- 支持开始、暂停、继续操作
- 实时显示累计暂停时间

### 任务管理
- 为每个倒计时设置任务标题
- 同时管理多个倒计时任务

### 用户界面
- 简洁现代的设计
- 粉红色和蓝色渐变色按钮
- 白色背景底色
- 支持深色模式切换
- 响应式布局，适配不同屏幕尺寸

## 目录结构

```
countdown-timer/
├── app/
│   └── app.py          # 主应用程序
├── templates/
│   └── index.html      # HTML模板
├── run.py              # 启动脚本
├── requirements.txt    # Python依赖
├── .gitignore          # Git忽略文件
└── README.md           # 项目说明
```

## 许可证

MIT License