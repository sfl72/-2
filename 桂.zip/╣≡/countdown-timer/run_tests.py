import unittest
import sys
import os

current_dir = os.path.dirname(os.path.abspath(__file__))
os.chdir(current_dir)

if 'venv' in os.listdir('.') and os.name == 'nt':
    # Windows
    activate_script = 'venv\\Scripts\\activate'
else:
    activate_script = 'source venv/bin/activate'

print("正在运行单元测试...")
print(f"使用Python: {sys.version}")
print("-" * 50)

# 发现并运行所有测试
loader = unittest.TestLoader()
suite = loader.discover('tests', pattern='test_*.py')

runner = unittest.TextTestRunner(verbosity=2)
result = runner.run(suite)

# 输出总结
print("\n" + "="*50)
if result.wasSuccessful():
    print("✅ 所有测试通过!")
    sys.exit(0)
else:
    print(f"❌ 测试失败: {result.testsRun - result.success_count} 个测试未通过")
    sys.exit(1)