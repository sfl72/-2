import os
import sys
import subprocess
import webbrowser
import time
import threading

def open_browser():
    """在应用启动后自动打开浏览器"""
    time.sleep(2)  # 等待应用启动
    webbrowser.open('http://localhost:5000')

if __name__ == '__main__':
    print("正在启动倒计时器应用...")
    print("访问 http://localhost:5000 查看应用")
    print("按 Ctrl+C 停止服务器")
    
    # 设置正确的Flask应用路径
    os.environ['FLASK_APP'] = 'app/app.py'
    os.environ['FLASK_ENV'] = 'development'
    
    # 启动浏览器打开线程
    browser_thread = threading.Thread(target=open_browser)
    browser_thread.daemon = True
    browser_thread.start()
    
    try:
        subprocess.run([sys.executable, '-m', 'flask', 'run'], check=True)
    except KeyboardInterrupt:
        print("\n服务器已停止")
    except subprocess.CalledProcessError as e:
        print(f"启动失败: {e}")
        sys.exit(1)