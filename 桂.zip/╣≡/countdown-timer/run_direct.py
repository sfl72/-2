import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), 'app'))

from app import app

if __name__ == "__main__":
    print("正在启动倒计时器应用...")
    print("访问 http://localhost:5000 查看应用")
    print("按 Ctrl+C 停止服务器")
    app.run(host='127.0.0.1', port=5000, debug=True)