from flask import Flask, render_template, jsonify, request
import threading
import time
import os

class CountdownTimer:
    def __init__(self, duration, title="", alarm_sounds=None):
        self.duration = duration
        self.title = title
        self.remaining = duration
        self.is_running = False
        self.is_paused = False
        self.pause_start_time = 0
        self.total_pause_time = 0
        self.alarm_sounds = alarm_sounds if alarm_sounds else []
        self.start_time = 0
        self.completed = False  # 添加完成标志
        self.just_completed = False  # 刚刚完成的标记
        self.has_local_audio = False  # 是否有本地音频文件
        self.completion_notified = False  # 是否已通知完成
    
    def start(self):
        if not self.is_running:
            self.is_running = True
            self.is_paused = False
            self.just_completed = False
            self.completion_notified = False  # 重启时重置通知状态
            if self.remaining == self.duration:
                self.start_time = time.time()
            self._run_timer()
    
    def pause(self):
        if self.is_running and not self.is_paused:
            self.is_paused = True
            self.pause_start_time = time.time()
    
    def resume(self):
        if self.is_paused:
            self.total_pause_time += time.time() - self.pause_start_time
            self.is_paused = False
    
    def _run_timer(self):
        def timer_thread():
            last_update = time.time()
            while self.is_running and self.remaining > 0:
                if not self.is_paused:
                    current_time = time.time()
                    # 更频繁地更新剩余时间，提高精度
                    if current_time - last_update >= 0.1:  # 每100毫秒更新一次
                        elapsed = current_time - self.start_time - self.total_pause_time
                        old_remaining = self.remaining
                        self.remaining = max(0, self.duration - int(round(elapsed)))
                        # 检查是否刚刚完成
                        if old_remaining > 0 and self.remaining == 0 and not self.completion_notified:
                            self.completed = True
                            self.just_completed = True
                            self.completion_notified = True
                        last_update = current_time
                    time.sleep(0.05)  # 减少睡眠时间以提高响应性
                else:
                    time.sleep(0.1)
            
            # 确保在循环结束后，如果计时器已完成，标记为完成
            if self.remaining == 0 and not self.completion_notified:
                self.completed = True
                self.just_completed = True
                self.completion_notified = True
        
        thread = threading.Thread(target=timer_thread)
        thread.daemon = True
        thread.start()
        
    def reset(self):
        """重置计时器"""
        self.remaining = self.duration
        self.is_running = False
        self.is_paused = False
        self.pause_start_time = 0
        self.total_pause_time = 0
        self.completed = False
        self.just_completed = False
        self.completion_notified = False
        self.start_time = 0

timers = []

# 获取项目根目录
basedir = os.path.abspath(os.path.dirname(__file__))
template_dir = os.path.join(os.path.dirname(basedir), 'templates')

app = Flask(__name__, template_folder=template_dir)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/timers', methods=['GET'])
def get_timers():
    """
    获取所有计时器的当前状态。
    
    Returns:
        JSON: 包含所有计时器信息的列表，每个计时器包含以下字段：
            - id (int): 计时器的唯一标识符。
            - duration (int): 计时器的总持续时间（秒）。
            - title (str): 计时器的标题。
            - remaining (int): 剩余时间（秒）。
            - is_running (bool): 计时器是否正在运行。
            - is_paused (bool): 计时器是否已暂停。
            - total_pause_time (float): 计时器累计的暂停时间。
            - alarm_sounds (list): 闹钟声音文件列表。
            - completed (bool): 计时器是否已完成。
            - just_completed (bool): 计时器是否刚刚完成（此标志需由前端通过acknowledge_completion API手动重置）。
            - has_local_audio (bool): 是否存在本地音频文件。
    """
    # 不再重置just_completed标志，由前端在处理完成后通过API调用重置
    return jsonify([{
        'id': i,
        'duration': t.duration,
        'title': t.title,
        'remaining': t.remaining,
        'is_running': t.is_running,
        'is_paused': t.is_paused,
        'total_pause_time': t.total_pause_time,
        'alarm_sounds': t.alarm_sounds,
        'completed': t.completed,
        'just_completed': t.just_completed,  # 返回刚刚完成的标记
        'has_local_audio': t.has_local_audio
    } for i, t in enumerate(timers)])

@app.route('/api/timer', methods=['POST'])
def create_timer():
    try:
        data = request.get_json()
        timer = CountdownTimer(
            data.get('duration', 60), 
            data.get('title', '新任务'),
            data.get('alarm_sounds', [])
        )
        timer.has_local_audio = data.get('has_local_audio', False)
        timers.append(timer)
        return jsonify({'success': True, 'id': len(timers) - 1})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 400

@app.route('/api/timer/<int:timer_id>/start', methods=['POST'])
def start_timer(timer_id):
    if 0 <= timer_id < len(timers):
        timers[timer_id].start()
        return jsonify({'success': True})
    return jsonify({'success': False, 'error': 'Timer not found'}), 404

@app.route('/api/timer/<int:timer_id>/pause', methods=['POST'])
def pause_timer(timer_id):
    if 0 <= timer_id < len(timers):
        timers[timer_id].pause()
        return jsonify({'success': True})
    return jsonify({'success': False, 'error': 'Timer not found'}), 404

@app.route('/api/timer/<int:timer_id>/resume', methods=['POST'])
def resume_timer(timer_id):
    if 0 <= timer_id < len(timers):
        timers[timer_id].resume()
        return jsonify({'success': True})
    return jsonify({'success': False, 'error': 'Timer not found'}), 404

@app.route('/api/timer/<int:timer_id>', methods=['DELETE'])
def delete_timer(timer_id):
    if 0 <= timer_id < len(timers):
        del timers[timer_id]
        return jsonify({'success': True})
    return jsonify({'success': False, 'error': 'Timer not found'}), 404

@app.route('/api/timer/<int:timer_id>/acknowledge_completion', methods=['POST'])
def acknowledge_completion(timer_id):
    """确认计时器完成状态已被处理"""
    if 0 <= timer_id < len(timers):
        timers[timer_id].just_completed = False
        return jsonify({'success': True})
    return jsonify({'success': False, 'error': 'Timer not found'}), 404

@app.route('/api/timer/<int:timer_id>/reset', methods=['POST'])
def reset_timer(timer_id):
    """重置计时器"""
    if 0 <= timer_id < len(timers):
        timers[timer_id].reset()
        return jsonify({'success': True})
    return jsonify({'success': False, 'error': 'Timer not found'}), 404

# 提供静态文件服务的路由
@app.route('/api/timer/<int:timer_id>/audio')
def get_timer_audio(timer_id):
    # 这里只是一个示例，实际项目中需要根据具体情况实现
    return jsonify({'error': '此功能需要额外的文件上传和存储机制'}), 404

if __name__ == '__main__':
    app.run(debug=True)