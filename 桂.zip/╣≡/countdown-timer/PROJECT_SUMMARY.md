# 项目概述

## 项目名称
倒计时器应用

## 项目目标
开发一个基于Web的倒计时器应用，支持多任务管理、暂停/继续功能、自定义铃声和深色模式切换。

## 主要功能
1. **倒计时功能**
   - 可以为每个倒计时设置自定义时长
   - 显示剩余时间（MM:SS格式）
   - 支持开始、暂停、继续操作
   - 实时显示累计暂停时间

2. **任务管理**
   - 为每个倒计时设置任务标题
   - 同时管理多个倒计时任务
   - 每个任务可关联多个铃声

3. **用户界面**
   - 简洁现代的设计
   - 粉红色和蓝色渐变色按钮
   - 白色背景底色
   - 支持深色模式切换
   - 响应式布局，适配不同屏幕尺寸

# 个人贡献细节

## 功能点实现

### 1. 核心计时器类 (`app/app.py`)
- 实现了 `CountdownTimer` 类，包含开始、暂停、继续和计时逻辑
- 记录累计暂停时间
- 支持为每个任务关联多个铃声

### 2. Flask Web API (`app/app.py`)
- 创建RESTful API端点用于管理计时器
- 实现创建、启动、暂停、继续计时器的功能
- 提供获取所有计时器状态的接口

### 3. 前端界面 (`templates/index.html`)
- 设计简洁美观的用户界面
- 实现粉红色和蓝色渐变色按钮
- 添加深色/浅色模式切换功能
- 使用Bootstrap 5构建响应式布局
- 实现动态更新计时器显示

### 4. 项目配置与工具
- 设置git版本控制，记录所有修改过程
- 创建requirements.txt管理Python依赖
- 开发setup.py用于环境设置
- 创建run_tests.py用于运行单元测试
- 开发check_project.py用于项目状态检查

# 软件工作流程和开发环境描述

## 开发环境
- **操作系统**: Windows 10/11
- **IDE**: VS Code
- **编程语言**: Python 3.7+
- **Web框架**: Flask
- **前端技术**: HTML, CSS, JavaScript, Bootstrap 5
- **版本控制**: Git

## 开发工具
- **VS Code插件**:
  - Python (Microsoft)
  - Pylance
  - GitLens
  - REST Client
  - Live Server

- **命令行工具**:
  - Git Bash
  - Python venv
  - pip package manager

## 软件工作流程

1. **项目初始化**
   ```bash
   # 创建项目目录
   mkdir countdown-timer
   cd countdown-timer
   
   # 初始化git仓库
   git init
   
   # 创建虚拟环境
   python -m venv venv
   ```

2. **开发流程**
   - 编写代码 → 运行测试 → 调试修复 → 提交到git
   - 每次功能变更都通过git提交记录历史版本
   - 使用check_project.py验证项目完整性

3. **测试流程**
   ```bash
   # 运行单元测试
   python run_tests.py
   
   # 或直接运行
   python -m unittest tests.test_app
   ```

4. **运行应用**
   ```bash
   # 激活虚拟环境
   venv\\Scripts\\activate  # Windows
   
   # 安装依赖
   pip install -r requirements.txt
   
   # 启动应用
   python run.py
   ```

5. **部署准备**
   - 确保所有测试通过
   - 验证项目完整性
   - 更新文档

## 技术架构

```
+-------------------+
|    浏览器         |
|  (HTML/CSS/JS)    |
+-------------------+
          ↓
+-------------------+
|   Flask Web服务器  |
|    (Python)       |
+-------------------+
          ↓
+-------------------+
|  CountdownTimer类  |
|  (业务逻辑)        |
+-------------------+
```

## 项目优势
- **模块化设计**: 代码结构清晰，易于维护和扩展
- **完整的测试覆盖**: 包含单元测试确保代码质量
- **良好的文档**: 详细的README和项目概要
- **自动化工具**: 提供多个脚本简化开发流程
- **版本控制**: 使用git完整记录开发历史