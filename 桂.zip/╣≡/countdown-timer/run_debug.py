import sys
import os
import logging

# 添加项目路径到Python路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))

# 配置日志
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

try:
    logger.debug("开始导入Flask应用")
    from app.app import app
    logger.debug("Flask应用导入成功")
    
    if __name__ == "__main__":
        logger.debug("启动Flask应用")
        print("正在启动倒计时器应用...")
        print("访问 http://localhost:5000 查看应用")
        print("按 Ctrl+C 停止服务器")
        app.run(host='127.0.0.1', port=5000, debug=True)
        
except Exception as e:
    logger.exception("应用启动时发生错误")
    print(f"错误详情: {e}")
    import traceback
    traceback.print_exc()