import unittest
import json
from app.app import app, timers

class TestCountdownTimer(unittest.TestCase):
    def setUp(self):
        self.app = app.test_client()
        self.app.testing = True
        # 清空计时器列表
        global timers
        timers.clear()
    
    def test_home_page(self):
        """测试主页是否正常加载"""
        response = self.app.get('/')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'<!DOCTYPE html>', response.data)
        self.assertIn(b'倒计时器', response.data)
    
    def test_create_timer(self):
        """测试创建计时器"""
        data = {
            'duration': 60,
            'title': '测试任务',
            'alarm_sounds': ['bell', 'chime']
        }
        response = self.app.post('/api/timer',
                               data=json.dumps(data),
                               content_type='application/json')
        self.assertEqual(response.status_code, 200)
        result = json.loads(response.data)
        self.assertTrue(result['success'])
        
        # 验证计时器已创建
        self.assertEqual(len(timers), 1)
        self.assertEqual(timers[0].title, '测试任务')
        self.assertEqual(timers[0].duration, 60)
        self.assertEqual(timers[0].alarm_sounds, ['bell', 'chime'])
    
    def test_get_timers(self):
        """测试获取计时器列表"""
        # 先创建一个计时器
        from app.app import CountdownTimer
        timer = CountdownTimer(60, '测试任务')
        timers.append(timer)
        
        response = self.app.get('/api/timers')
        self.assertEqual(response.status_code, 200)
        result = json.loads(response.data)
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]['title'], '测试任务')
    
    def test_start_pause_resume_timer(self):
        """测试计时器的开始、暂停和继续功能"""
        # 创建计时器
        data = {'duration': 5, 'title': '测试任务'}
        self.app.post('/api/timer',
                     data=json.dumps(data),
                     content_type='application/json')
        
        # 开始计时器
        response = self.app.post('/api/timer/0/start')
        self.assertEqual(response.status_code, 200)
        result = json.loads(response.data)
        self.assertTrue(result['success'])
        
        # 暂停计时器
        response = self.app.post('/api/timer/0/pause')
        self.assertEqual(response.status_code, 200)
        result = json.loads(response.data)
        self.assertTrue(result['success'])
        
        # 继续计时器
        response = self.app.post('/api/timer/0/resume')
        self.assertEqual(response.status_code, 200)
        result = json.loads(response.data)
        self.assertTrue(result['success'])

if __name__ == '__main__':
    unittest.main()